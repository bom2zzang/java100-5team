package java100.app.domain;

public class UploadFile {

    public UploadFile() {
    }
    
    public UploadFile(String filename, String Thumbnail) {

    }

    public UploadFile(String filename) {
    }
/*
    // 나중에 삭제 
    public int getCodyNo() {
        return codyNo;
    }
    // 나중에 삭제 
    public void setCodyNo(int codyNo) {
        this.codyNo = codyNo;
    }*/
}
