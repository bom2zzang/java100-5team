package java100.app.web;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;

import java100.app.domain.Cody;
import java100.app.domain.Cody_Comment;
import java100.app.domain.Liked;
import java100.app.domain.Member;
import java100.app.domain.UploadFile;
import java100.app.service.CodyService;
import java100.app.service.Cody_CommentService;
import java100.app.service.LikedService;
import java100.app.service.TrendService;

@Controller
@RequestMapping("/cody")
@SessionAttributes("loginUser")
public class CodyController {

    @Autowired   ServletContext servletContext;
    @Autowired  CodyService codyService;
    @Autowired  LikedService likedService;
    @Autowired  Cody_CommentService cody_commentService;
    @Autowired TrendService trendService;
    
   /* @Autowired FriendService friendService;*/
    
    
    
    @ModelAttribute(value = "loginUser")
    public Member loginUser() {
        
        Member loginUser = new Member();
        
        return loginUser;
    }
    
    @RequestMapping("list")
    public String list(@RequestParam(value = "pn", defaultValue = "1") int pageNo,
            @RequestParam(value = "ps", defaultValue = "5") int pageSize,
            @RequestParam(value = "words", required = false) String[] words,
            @RequestParam(value = "tops", required = false) String[] tops,
            @RequestParam(value = "pants", required = false) String[] pants,
            @RequestParam(value = "oc", required = false) String orderColumn,
            @RequestParam(value = "al", required = false) String align, Model model,
            @ModelAttribute(value = "loginUser") Member loginUser
        ) throws Exception {
        
      
        if (pageNo < 1) {
            pageNo = 1;
        }

        if (pageSize < 5 || pageSize > 15) {
            pageSize = 5;
        }
        
        
        HashMap<String, Object> options = new HashMap<>();
        if (words != null && words[0].length() > 0) {
            options.put("words", words);
        }else if(tops != null && tops[0].length() > 0) {
            options.put("tops", tops);
        }else if(pants != null && pants[0].length() > 0) {
            options.put("pants", pants);
        }
        
        options.put("orderColumn", orderColumn);
        options.put("align", align);

        int totalCount = codyService.getTotalCount();
        int lastPageNo = totalCount / pageSize;
        if ((totalCount % pageSize) > 0) {
            lastPageNo++;
        }
        
        model.addAttribute("pageNo", pageNo);
        model.addAttribute("lastPageNo", lastPageNo);
       
       /* model.addAttribute("findByMyNo", friendService.get(loginUser.getM_no()));
        model.addAttribute("findFriend", friendService.list(loginUser.getM_no()));*/
        model.addAttribute("list", codyService.list(pageNo, pageSize, options));
        model.addAttribute("list1", trendService.list1(options));
        return "cody/list";
    }

    @RequestMapping("{co_no},{writer_no}")
    public String view(@PathVariable int co_no, Model model, @ModelAttribute(value = "loginUser") Member loginUser, Cody cody, Cody_Comment cody_comment) throws Exception {
        
        System.out.println(loginUser.getM_no()+"도착~~~~~~~~~~~~~~~~~~");
        System.out.println(cody);
       
        if(cody.getWriter_no() != loginUser.getM_no()) {
            model.addAttribute("lista", likedService.list(co_no));
            model.addAttribute("cody", codyService.get(co_no));
            model.addAttribute("listcomment", cody_commentService.list(co_no));
            
            System.out.println(loginUser);
            cody_comment.setM_no(loginUser.getM_no());
            cody_comment.setId(loginUser.getId());
            model.addAttribute("formcomment", cody_comment);
            return "cody/viewNOupdate";
        }else{
            
        
        model.addAttribute("cody", codyService.get(co_no));
       
        model.addAttribute("lista", likedService.list(co_no));
        model.addAttribute("listcomment", cody_commentService.list(co_no));
        
        System.out.println(loginUser);
        cody_comment.setM_no(loginUser.getM_no());
        cody_comment.setId(loginUser.getId());
        model.addAttribute("formcomment", cody_comment);
        
        return "cody/view";
        }
    }

    @RequestMapping("form")
    public String form() throws Exception {
        return "cody/form";

    }

    //@Transactional
    @RequestMapping("add")
    public String add(Cody cody, MultipartFile[] file, @ModelAttribute(value = "loginUser") Member loginUser)
            throws Exception {
        
        System.out.println(loginUser);
        System.out.println(cody);
        System.out.println(cody.getCo_no());
        System.out.println(loginUser.getM_no());
        
        String uploadDir = servletContext.getRealPath("/download");
      
        ArrayList<UploadFile> uploadFiles = new ArrayList<>();

        for (MultipartFile part : file) {
            if (part.isEmpty())
                continue;

            String filename = this.writeUploadFile(part, uploadDir);
            
            cody.setCo_photo(filename);
            uploadFiles.add(new UploadFile(filename));
        }
        
        System.out.println(cody.getWriter());
        cody.setWriter(loginUser);
        
        System.out.println(cody.getWriter_no());
        System.out.println(loginUser.getM_no());
        System.out.println("---------------------");
        //cody.setM_no(loginUser.getM_no());
        codyService.add(cody);
        

        return "redirect:list";
    }

    @RequestMapping("update")
    public String update(Cody cody, MultipartFile[] file, @ModelAttribute(value = "loginUser") Member loginUser, Liked liked) throws Exception {

        String uploadDir = servletContext.getRealPath("/download");

        ArrayList<UploadFile> uploadFiles = new ArrayList<>();

        for (MultipartFile part : file) {
            if (part.isEmpty())
                continue;

            String filename = this.writeUploadFile(part, uploadDir);

            cody.setCo_photo(filename);
            
            //uploadFiles.add(new UploadFile(filename));
        }
        
        System.out.println(cody.getCo_photo());
        System.out.println(cody.getTitle());
       
        
        codyService.update(cody);

        return "redirect:list";
    }
    
    @RequestMapping("liked")
    public String liked(Cody cody, MultipartFile[] file, @ModelAttribute(value = "loginUser") Member loginUser, Liked liked) throws Exception {
        
        
        liked.setCo_no(cody.getCo_no());
        liked.setM_no(loginUser.getM_no());
        liked.setName(loginUser.getEmail());
        
        liked.setLikedcount(+1);
     
        cody.setLiked(liked);
        try {
            codyService.liked(cody);
        }catch (Exception e) {
           System.out.println("중복으로 누를수 없습니다.");
           //return "redirect:"+cody.getCo_no()+","+cody.getWtest()+"";
           
           return "redirect:"+cody.getCo_no()+","+cody.getWriter_no()+"";
        }
        
        return "redirect:list";
    }
    
    @RequestMapping("delete")
    public String delete(int co_no) throws Exception {
        
        
        cody_commentService.deleteByCo_no(co_no);
        
        likedService.delete(co_no);
        codyService.delete(co_no);
        
        return "redirect:list";
    }

    long prevMillis = 0;
    int count = 0;

    synchronized private String getNewFilename(String filename) {
        long currMillis = System.currentTimeMillis();
        if (prevMillis != currMillis) {
            count = 0;
            prevMillis = currMillis;
        }

        return currMillis + "_" + count++ + extractFileExtName(filename);
    }

    private String extractFileExtName(String filename) {
        int dotPosition = filename.lastIndexOf(".");

        if (dotPosition == -1)
            return "";

        return filename.substring(dotPosition);
    }

    private String writeUploadFile(MultipartFile part, String path) throws IOException {

        String filename = getNewFilename(part.getOriginalFilename());
      
        part.transferTo(new File(path + "/" + filename));
        return filename;
    }
}